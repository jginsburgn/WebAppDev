
exports.homeController = function (req,res){
	res.render('index', { title: 'Express' });
}